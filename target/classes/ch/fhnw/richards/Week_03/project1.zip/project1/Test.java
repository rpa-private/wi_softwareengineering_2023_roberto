package ch.fhnw.richards.Week_03.project1;

import ch.fhnw.richards.Week_03.project1.AStar;
import ch.fhnw.richards.Week_03.project1.BestFirst;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Test {
    public static void main(String[] args) throws Exception {
        // Configure custom locations via -Dcsv.dir=/path or environment CSV_DIR
        MapData mapData = new MapData();

        // Show nodes (lon/lat)
        Map<String, MapData.GPS> nodes = mapData.getNodes();
        for (String node : nodes.keySet()) {
            MapData.GPS gps = nodes.get(node);
            System.out.printf("%s: (lon=%.6f, lat=%.6f)%n", node, gps.east(), gps.north());
        }

        System.out.println("=========================");

        // Choose a start and goal that exist in the provided sample CSVs
        String start = "Rothrist/Schellberweg/1";
        String goal  = "Olten/Von Roll-Strasse/4";

        // Best-First Search
        List<String> bestFirstPath = BestFirst.search(mapData, start, goal);
        System.out.println("BestFirst path: " + bestFirstPath);
        System.out.printf("BestFirst length (sum of edges): %.1f m%n",
                BestFirst.pathDistance(mapData, bestFirstPath));

        // A* Search
        List<String> aStarPath = AStar.search(mapData, start, goal);
        System.out.println("A* path: " + aStarPath);
        System.out.printf("A* length (sum of edges): %.1f m%n",
                AStar.pathDistance(mapData, aStarPath));
    }
}
